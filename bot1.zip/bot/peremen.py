# peremen.py

# ===== Telegram =====
BOT_TOKEN = "8300706935:AAHzjPIbl2-du8RPf-pFsPtoGlkAqsjrfjM"
ADMIN_ID = 1826890259  # твой Telegram user_id (число)

# ===== YooKassa =====
YOO_SHOP_ID = "1245765"
YOO_SECRET = "test__a0rhFp_5fxhSGDkSWOeTp8cWE2OrpkkaBBTEtr0drI"
YOO_MODE = "TEST"  # TEST / PROD
YOO_RETURN_URL = "https://example.com/return"

# ===== Канал (куда выдаём доступ) =====
PRIVATE_CHANNEL_ID = -1003536058024  # numeric id канала -100...

# ===== Продукт =====
PRICE_RUB = 700
CURRENCY = "RUB"
DESCRIPTION = "Мама твоя"

# ===== База =====
DB_PATH = "bot.db"

# (опционально) контакт поддержки
SUPPORT_TEXT = "Если есть проблема с оплатой/доступом — напиши администратору."