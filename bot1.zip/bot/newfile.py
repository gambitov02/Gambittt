import os
import uuid
import base64
import json
from typing import Dict, Any

import aiohttp
from aiohttp import web

from aiogram import Bot, Dispatcher, F
from aiogram.types import Message
from aiogram.filters import Command
BOT_TOKEN = "8300706935:AAEUtS_MY9z0lRFYJ7euZgxm6Pw-YxYHtbc"
YOO_SHOP_ID = "1245765"
YOO_SECRET = "test__a0rhFp_5fxhSGDkSWOeTp8cWE2OrpkkaBBTEtr0drI"
YOO_RETURN_URL = os.getenv("YOO_RETURN_URL", "https://example.com/return")  # куда вернется пользователь
YOO_WEBHOOK_SECRET = os.getenv("YOO_WEBHOOK_SECRET", "")  # опционально, если настроишь проверку
PRIVATE_CHANNEL_ID = int(os.getenv("PRIVATE_CHANNEL_ID", "-1001234567890"))
YOO_MODE = os.getenv("YOO_MODE", "TEST").upper()  # TEST или PROD
PRICE_RUB = 700
CURRENCY = "RUB"

# В проде — хранить в БД
pending_payments: Dict[str, int] = {}  # payment_id -> user_id


def yookassa_auth_header() -> str:
    # Basic Auth: shop_id:secret_key
    token = base64.b64encode(f"{YOO_SHOP_ID}:{YOO_SECRET}".encode()).decode()
    return f"Basic {token}"


async def create_payment(user_id: int) -> Dict[str, Any]:
    """
    TEST  -> bank_card
    PROD  -> sbp (если подключено)
    """
    idempotence_key = str(uuid.uuid4())

    # В тестовом магазине СБП обычно недоступно
    method = "bank_card" if YOO_MODE == "TEST" else "sbp"

    payload = {
        "amount": {"value": f"{PRICE_RUB}.00", "currency": CURRENCY},
        "capture": True,
        "description": "7-дневный челлендж: Верни фокус и начни учиться",
        "confirmation": {"type": "redirect", "return_url": YOO_RETURN_URL},
        "metadata": {"tg_user_id": str(user_id)},
        "payment_method_data": {"type": method},
    }

    headers = {
        "Authorization": yookassa_auth_header(),
        "Content-Type": "application/json",
        "Idempotence-Key": idempotence_key,
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://api.yookassa.ru/v3/payments",
            headers=headers,
            data=json.dumps(payload),
            timeout=20,
        ) as resp:
            text = await resp.text()
            if resp.status >= 400:
                raise RuntimeError(f"YooKassa error {resp.status}: {text}")
            return json.loads(text)


# ---- aiogram handlers ----

async def cmd_start(message: Message):
    await message.answer(
        "Привет! 👋\n"
        "Чтобы попасть в 7-дневный челлендж, нажми: /pay"
    )


async def cmd_pay(message: Message, bot: Bot):
    user_id = message.from_user.id
    payment = await create_payment(user_id)
    payment_id = payment["id"]
    pending_payments[payment_id] = user_id

    confirmation_url = payment["confirmation"]["confirmation_url"]
    await message.answer(
    "🔥 Готово!\n"
    "Оплати по ссылке ниже:\n"
    f"{confirmation_url}\n\n"
    "После оплаты доступ выдастся автоматически."
)
    


# ---- YooKassa webhook ----

async def yookassa_webhook(request: web.Request):
    """
    YooKassa шлёт события типа payment.succeeded / payment.canceled.
    """
    data = await request.json()

    event = data.get("event")
    obj = data.get("object", {})
    payment_id = obj.get("id")
    status = obj.get("status")

    # при желании — проверяй подпись/секрет (зависит от твоей настройки в YooKassa)
    # Также можно сверять metadata.tg_user_id

    if not payment_id:
        return web.Response(status=400, text="no payment id")

    user_id = pending_payments.get(payment_id)

    if event == "payment.succeeded" and status == "succeeded" and user_id:
        bot: Bot = request.app["bot"]
        await handle_success(bot, payment_id, user_id)
        pending_payments.pop(payment_id, None)

    return web.Response(status=200, text="ok")


async def main():
    bot = Bot(BOT_TOKEN)
    dp = Dispatcher()

    dp.message.register(cmd_start, Command("start"))
    dp.message.register(cmd_pay, Command("pay"))

    # aiohttp app for webhooks
    app = web.Application()
    app["bot"] = bot
    app.router.add_post("/yookassa/webhook", yookassa_webhook)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host="0.0.0.0", port=int(os.getenv("PORT", "8080")))
    await site.start()

    await dp.start_polling(bot)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())