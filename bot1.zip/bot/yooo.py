import os
import uuid
import base64
import json
from typing import Dict, Any, Optional

import aiohttp
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
import logging
logging.basicConfig(level=logging.INFO)


# ================== НАСТРОЙКИ ==================
BOT_TOKEN = "8300706935:AAHzjPIbl2-du8RPf-pFsPtoGlkAqsjrfjM"

# Для тестового магазина лучше вставить строками (или через env)
YOO_SHOP_ID = "1245765"
YOO_SECRET = "test__a0rhFp_5fxhSGDkSWOeTp8cWE2OrpkkaBBTEtr0drI"

# TEST -> bank_card, PROD -> sbp (если СБП подключено в боевом)
YOO_MODE = (os.getenv("YOO_MODE") or "TEST").upper()  # TEST / PROD

YOO_RETURN_URL = os.getenv("YOO_RETURN_URL") or "https://example.com/return"

# ВАЖНО: numeric chat_id вида -100..., НЕ ссылка
PRIVATE_CHANNEL_ID = int(os.getenv("PRIVATE_CHANNEL_ID") or "-1003536058024")

PRICE_RUB = 700
CURRENCY = "RUB"
DESCRIPTION = "7-дневный челлендж: Верни фокус и начни учиться"
# ===============================================


# Простое хранилище для теста (в проде — БД)
last_payment_by_user: Dict[int, str] = {}  # user_id -> payment_id


def yookassa_auth_header() -> str:
    token = base64.b64encode(f"{YOO_SHOP_ID}:{YOO_SECRET}".encode()).decode()
    return f"Basic {token}"


async def yk_create_payment(user_id: int) -> Dict[str, Any]:
    idempotence_key = str(uuid.uuid4())

    method = "bank_card" if YOO_MODE == "TEST" else "sbp"

    payload = {
        "amount": {"value": f"{PRICE_RUB}.00", "currency": CURRENCY},
        "capture": True,
        "description": DESCRIPTION,
        "confirmation": {"type": "redirect", "return_url": YOO_RETURN_URL},
        "payment_method_data": {"type": method},
        "metadata": {"tg_user_id": str(user_id)},
    }

    headers = {
        "Authorization": yookassa_auth_header(),
        "Content-Type": "application/json",
        "Idempotence-Key": idempotence_key,
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://api.yookassa.ru/v3/payments",
            headers=headers,
            data=json.dumps(payload),
            timeout=20,
        ) as resp:
            text = await resp.text()
            if resp.status >= 400:
                raise RuntimeError(f"YooKassa error {resp.status}: {text}")
            return json.loads(text)


async def yk_get_payment(payment_id: str) -> Dict[str, Any]:
    headers = {"Authorization": yookassa_auth_header()}

    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"https://api.yookassa.ru/v3/payments/{payment_id}",
            headers=headers,
            timeout=20,
        ) as resp:
            text = await resp.text()
            if resp.status >= 400:
                raise RuntimeError(f"YooKassa error {resp.status}: {text}")
            return json.loads(text)


async def issue_invite_link(bot: Bot) -> str:
    invite = await bot.create_chat_invite_link(
        chat_id=PRIVATE_CHANNEL_ID,
        member_limit=1,
        creates_join_request=False,
    )
    return invite.invite_link


dp = Dispatcher()


@dp.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "Привет! 👋\n\n"
        "Команды:\n"
        "/pay — создать ссылку на оплату\n"
        "/check — проверить оплату и получить доступ\n\n"
        "Если что-то не работает — напиши, помогу."
    )


@dp.message(Command("pay"))
async def cmd_pay(message: Message, bot: Bot):
    user_id = message.from_user.id

    try:
        payment = await yk_create_payment(user_id)
    except Exception as e:
        await message.answer(f"Ошибка при создании платежа: {e}")
        return

    payment_id = payment["id"]
    last_payment_by_user[user_id] = payment_id

    confirmation_url = payment["confirmation"]["confirmation_url"]
    await message.answer(
    "🔥 Платёж создан!\n\n"
    f"1) Оплати по ссылке:\n{confirmation_url}\n\n"
    "2) После оплаты вернись сюда и напиши: /check\n\n"
    f"Твой payment_id: {payment_id}"

    )


@dp.message(Command("check"))
async def cmd_check(message: Message, bot: Bot):
    user_id = message.from_user.id

    # /check <payment_id> (необязательно)
    parts = (message.text or "").split(maxsplit=1)
    payment_id: Optional[str] = None
    if len(parts) == 2:
        payment_id = parts[1].strip()

    if not payment_id:
        payment_id = last_payment_by_user.get(user_id)

    if not payment_id:
        await message.answer("Я не вижу твоего платежа. Сначала сделай /pay, потом /check.")
        return

    try:
        payment = await yk_get_payment(payment_id)
    except Exception as e:
        await message.answer(f"Ошибка при проверке платежа: {e}")
        return

    status = payment.get("status")
    meta = payment.get("metadata") or {}
    tg_user_in_meta = str(meta.get("tg_user_id", ""))

    # Защита: платёж должен быть создан для этого пользователя
    if tg_user_in_meta and tg_user_in_meta != str(user_id):
        await message.answer("Этот payment_id не принадлежит тебе. Создай новый платёж через /pay.")
        return

    if status == "succeeded":
        try:
            link = await issue_invite_link(bot)
        except Exception as e:
            await message.answer(
                "Оплата прошла ✅, но я не смог выдать ссылку в канал.\n"
                f"Причина: {e}\n\n"
                "Проверь: бот админ канала и есть право приглашать."
            )
            return

        await message.answer(
            "✅ Оплата подтверждена!\n\n"
            f"Вот доступ в закрытый канал:\n{link}\n\n"
            "Если ссылка не открывается — напиши мне."
        )
    elif status in ("pending", "waiting_for_capture"):
        await message.answer(
            f"Платёж пока не завершён (status: {status}).\n"
            "Если ты только что оплатил — подожди 10–30 секунд и попробуй снова: /check"
        )
    else:
        await message.answer(f"Платёж не оплачен (status: {status}). Если нужно — сделай /pay заново.")


async def main():
    print("Starting bot...")

    bot = Bot(BOT_TOKEN)
    me = await bot.get_me()
    print("Logged in as:", me.username)

    await bot.delete_webhook(drop_pending_updates=True)
    print("Webhook cleared, start polling...")
    print("Bot is running and polling...")

    if not BOT_TOKEN or "PASTE_" in BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN не задан. Вставь токен или установи переменную окружения BOT_TOKEN.")
    if not YOO_SHOP_ID or "PASTE_" in YOO_SHOP_ID or not YOO_SECRET or "PASTE_" in YOO_SECRET:
        raise RuntimeError("YOO_SHOP_ID / YOO_SECRET не заданы. Вставь тестовые ключи ЮKassa.")

    bot = Bot(BOT_TOKEN)

    # чтобы polling не конфликтовал с webhook
    await bot.delete_webhook(drop_pending_updates=True)

    await dp.start_polling(bot, allowed_updates=["message"])

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())