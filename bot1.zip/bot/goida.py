import os
import uuid
import base64
import json
from typing import Dict, Any, Optional

import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from peremen import (
    BOT_TOKEN,
    ADMIN_ID,
    YOO_SHOP_ID,
    YOO_SECRET,
    YOO_MODE,
    YOO_RETURN_URL,
    PRIVATE_CHANNEL_ID,
    PRICE_RUB,
    CURRENCY,
    DESCRIPTION,
    DB_PATH,
)

# ================== НАСТРОЙКИ ==================
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME") or "gambitovtestbot"  # можно заменить на @username друга
# ===============================================


# В проде — БД. Здесь для теста в памяти:
last_payment_by_user: Dict[int, str] = {}   # user_id -> payment_id
access_issued_for_payment: Dict[str, bool] = {}  # payment_id -> True


def yookassa_auth_header() -> str:
    token = base64.b64encode(f"{YOO_SHOP_ID}:{YOO_SECRET}".encode()).decode()
    return f"Basic {token}"


def main_menu_kb() -> InlineKeyboardBuilder:
    kb = InlineKeyboardBuilder()
    kb.button(text="💳 Оплатить участие", callback_data="pay")
    kb.button(text="✅ Проверить оплату", callback_data="check")
    kb.button(text="🔗 Получить доступ", callback_data="access")
    kb.button(text="🆘 Поддержка", callback_data="support")
    kb.adjust(1)
    return kb


async def yk_create_payment(user_id: int) -> Dict[str, Any]:
    idempotence_key = str(uuid.uuid4())
    method = "bank_card" if YOO_MODE == "TEST" else "sbp"

    payload = {
        "amount": {"value": f"{PRICE_RUB}.00", "currency": CURRENCY},
        "capture": True,
        "description": DESCRIPTION,
        "confirmation": {"type": "redirect", "return_url": YOO_RETURN_URL},
        "payment_method_data": {"type": method},
        "metadata": {"tg_user_id": str(user_id)},
    }

    headers = {
        "Authorization": yookassa_auth_header(),
        "Content-Type": "application/json",
        "Idempotence-Key": idempotence_key,
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://api.yookassa.ru/v3/payments",
            headers=headers,
            data=json.dumps(payload),
            timeout=20,
        ) as resp:
            text = await resp.text()
            if resp.status >= 400:
                raise RuntimeError(f"YooKassa error {resp.status}: {text}")
            return json.loads(text)


async def yk_get_payment(payment_id: str) -> Dict[str, Any]:
    headers = {"Authorization": yookassa_auth_header()}

    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"https://api.yookassa.ru/v3/payments/{payment_id}",
            headers=headers,
            timeout=20,
        ) as resp:
            text = await resp.text()
            if resp.status >= 400:
                raise RuntimeError(f"YooKassa error {resp.status}: {text}")
            return json.loads(text)


async def issue_invite_link(bot: Bot) -> str:
    invite = await bot.create_chat_invite_link(
        chat_id=PRIVATE_CHANNEL_ID,
        member_limit=1,
        creates_join_request=False,
    )
    return invite.invite_link


async def check_last_payment(user_id: int) -> tuple[str, Optional[Dict[str, Any]]]:
    """
    Возвращает (status_text, payment_obj_or_none)
    """
    payment_id = last_payment_by_user.get(user_id)
    if not payment_id:
        return ("❗ У тебя пока нет созданного платежа.\nНажми «Оплатить участие».", None)

    payment = await yk_get_payment(payment_id)
    status = payment.get("status", "unknown")
    return (status, payment)


dp = Dispatcher()


# ---------- Команды ----------
@dp.message(Command("start"))
async def cmd_start(message: Message):
    text = (
        "👋 Привет!\n\n"
        "Я бот для участия в 7-дневном челлендже по учёбе.\n\n"
        f"💰 Стоимость: {PRICE_RUB} ₽\n"
        "Что делать:\n"
        "1) Нажми «Оплатить участие»\n"
        "2) Оплати по ссылке\n"
        "3) Нажми «Проверить оплату»\n"
        "4) Получи ссылку в закрытый канал\n\n"
        "Жми кнопку ниже 👇"
    )
    await message.answer(text, reply_markup=main_menu_kb().as_markup())


@dp.message(Command("menu"))
async def cmd_menu(message: Message):
    await message.answer("Меню 👇", reply_markup=main_menu_kb().as_markup())


# ---------- Callback кнопки ----------
@dp.callback_query(F.data == "pay")
async def cb_pay(call: CallbackQuery, bot: Bot):
    user_id = call.from_user.id
    await call.answer()

    try:
        payment = await yk_create_payment(user_id)
    except Exception as e:
        await call.message.answer(f"❌ Не смог создать платёж.\nПричина: {e}")
        return

    payment_id = payment["id"]
    last_payment_by_user[user_id] = payment_id
    confirmation_url = payment["confirmation"]["confirmation_url"]

    await call.message.answer(
        "💳 Платёж создан!\n\n"
        "1) Оплати по ссылке:\n"
        f"{confirmation_url}\n\n"
        "2) После оплаты нажми «Проверить оплату» ✅\n\n"
        f"🧾 ID платежа: {payment_id}",
        reply_markup=main_menu_kb().as_markup(),
    )


@dp.callback_query(F.data == "check")
async def cb_check(call: CallbackQuery, bot: Bot):
    user_id = call.from_user.id
    await call.answer()

    payment_id = last_payment_by_user.get(user_id)
    if not payment_id:
        await call.message.answer("❗ Сначала создай платёж: нажми «Оплатить участие».")
        return

    try:
        payment = await yk_get_payment(payment_id)
    except Exception as e:
        await call.message.answer(f"❌ Ошибка при проверке платежа:\n{e}")
        return

    status = payment.get("status", "unknown")
    if status == "succeeded":
        await call.message.answer(
            "✅ Оплата найдена и подтверждена!\n"
            "Нажми «Получить доступ» 🔗",
            reply_markup=main_menu_kb().as_markup(),
        )
    elif status in ("pending", "waiting_for_capture"):
        await call.message.answer(
            "⏳ Пока не вижу подтверждения оплаты.\n"
            "Если ты только что оплатил — подожди 10–30 секунд и нажми «Проверить оплату» ещё раз.",
            reply_markup=main_menu_kb().as_markup(),
        )
    else:
        await call.message.answer(
            f"⚠️ Статус платежа: {status}\n"
            "Если оплата не прошла — нажми «Оплатить участие» и создай новый платёж.",
            reply_markup=main_menu_kb().as_markup(),
        )


@dp.callback_query(F.data == "access")
async def cb_access(call: CallbackQuery, bot: Bot):
    user_id = call.from_user.id
    await call.answer()

    payment_id = last_payment_by_user.get(user_id)
    if not payment_id:
        await call.message.answer("❗ Сначала нажми «Оплатить участие».")
        return

    # защита от повторной выдачи
    if access_issued_for_payment.get(payment_id):
        await call.message.answer(
            "🔁 Доступ уже выдавался по этому платежу.\n"
            "Если ссылка не открывается — напиши в поддержку.",
            reply_markup=main_menu_kb().as_markup(),
        )
        return

    try:
        payment = await yk_get_payment(payment_id)
    except Exception as e:
        await call.message.answer(f"❌ Не смог проверить платёж:\n{e}")
        return

    status = payment.get("status")
    meta = payment.get("metadata") or {}
    if str(meta.get("tg_user_id", "")) not in ("", str(user_id)):
        await call.message.answer("❌ Этот платёж не твой. Создай новый платёж через «Оплатить участие».")
        return

    if status != "succeeded":
        await call.message.answer(
            f"⛔ Оплата ещё не подтверждена (status: {status}).\n"
            "Нажми «Проверить оплату» ✅",
            reply_markup=main_menu_kb().as_markup(),
        )
        return

    # выдача ссылки
    try:
        link = await issue_invite_link(bot)
    except Exception as e:
        await call.message.answer(
            "✅ Оплата есть, но не могу выдать ссылку в канал.\n"
            f"Причина: {e}\n\n"
            "Проверь, что бот админ канала и у него есть право создавать пригласительные ссылки.",
        )
        return

    access_issued_for_payment[payment_id] = True
    await call.message.answer(
        "🎉 Готово! Вот ссылка в закрытый канал:\n"
        f"{link}\n\n"
        "Если ссылка не открывается — напиши в поддержку 🆘",
        reply_markup=main_menu_kb().as_markup(),
    )


@dp.callback_query(F.data == "support")
async def cb_support(call: CallbackQuery):
    await call.answer()
    await call.message.answer(
        "🆘 Поддержка\n\n"
        "Напиши сюда, если:\n"
        "• оплатил(а), но статус не подтверждается\n"
        "• ссылка не открывается\n"
        "• случайно закрыл(а) ссылку\n\n"
        f"Контакт: @{SUPPORT_USERNAME}"
    )


async def main():
    print("CONFIG:")
    print("ADMIN_ID =", ADMIN_ID)
    print("CHANNEL =", PRIVATE_CHANNEL_ID)
    print("PRICE =", PRICE_RUB)
    if "PASTE_" in BOT_TOKEN:
        raise RuntimeError("Вставь BOT_TOKEN")
    if "PASTE_" in YOO_SHOP_ID or "PASTE_" in YOO_SECRET:
        raise RuntimeError("Вставь YOO_SHOP_ID и YOO_SECRET")

    bot = Bot(BOT_TOKEN)
    await bot.delete_webhook(drop_pending_updates=True)

    # Чтобы не ловить апдейты из канала (и не ломаться на channel_post)
    await dp.start_polling(bot, allowed_updates=["message", "callback_query"])


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())